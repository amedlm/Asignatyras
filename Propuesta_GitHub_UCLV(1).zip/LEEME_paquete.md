# Propuesta de Organización de Recursos Educativos en GitHub

Este paquete contiene la propuesta completa de organización de los recursos
educativos de las asignaturas **Web Semántica** y **Análisis Documental I** de
la UCLV, dentro del Programa de Formación Continua.

## Contenido

```
download/
├── Propuesta_GitHub_Recursos_Educativos_UCLV.pdf   ← Documento principal
└── github-uclv-cinfo/                              ← Estructura lista para subir
    ├── .github/profile/README.md                   ← Perfil de la organización
    │
    ├── web-semantica/                              ← Repositorio 1
    │   ├── README.md
    │   ├── LICENSE                                 (CC BY-SA 4.0)
    │   ├── CONTRIBUTING.md
    │   ├── CODE_OF_CONDUCT.md
    │   ├── .gitignore
    │   └── .github/
    │       ├── PULL_REQUEST_TEMPLATE.md
    │       └── ISSUE_TEMPLATE/
    │           ├── duda-contenido.md
    │           ├── error-material.md
    │           └── entrega-practica.yml
    │
    └── analisis-documental/                        ← Repositorio 2
        ├── README.md
        ├── LICENSE                                 (CC BY-SA 4.0)
        ├── CONTRIBUTING.md
        ├── CODE_OF_CONDUCT.md
        ├── .gitignore
        └── .github/
            ├── PULL_REQUEST_TEMPLATE.md
            └── ISSUE_TEMPLATE/
                ├── duda-contenido.md
                ├── error-material.md
                └── entrega-practica.yml
```

## Cómo usar

1. **Lee primero el PDF** `Propuesta_GitHub_Recursos_Educativos_UCLV.pdf` para
   entender la justificación, arquitectura y roadmap.

2. **Crea la organización en GitHub** con nombre `uclv-cinfo` (o el que
   prefieras) y solicita GitHub Education.

3. **Crea los dos repositorios** `web-semantica` y `analisis-documental`
   dentro de la organización.

4. **Sube los archivos** de las carpetas `web-semantica/` y
   `analisis-documental/` a los repositorios respectivos.

5. **Sube el perfil de la organización** copiando el contenido de
   `.github/profile/README.md` al repositorio especial
   `uclv-cinfo/.github` (que GitHub muestra en la home de la organización).

6. **Sigue el roadmap** descrito en la sección 10 del PDF para las fases de
   migración, configuración de plantillas, pilotaje y despliegue.

## Licencia

Todo el material de este paquete se distribuye bajo
[CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/).

## Autor

**Amed Leiva-Mederos** · Profesor Titular · UCLV
- Correo: amedcuba73@gmail.com
- ORCID: <https://orcid.org/0009-0001-5050-5563>
