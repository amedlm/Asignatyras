---
name: Duda sobre el contenido
about: Pregunta sobre teoría, ejemplos o prácticas del curso
title: "[DUDA] <unidad> - <resumen corto>"
labels: ["duda", "needs-triage"]
assignees: []
---

## Unidad afectada
<!-- ej. u3-indizacion -->

## Sección del material
<!-- ej. teoria/01-tesauros.pdf, slide 12 -->

## Descripción de la duda
<!-- Explica con tus palabras qué no entiendes -->

## Lo que intenté
<!-- Pega aquí tu registro MARC 21, dublin core, o los pasos seguidos -->
```
# Tu código o registro aquí
```

## Contexto adicional
<!-- Capturas, enlaces, referencias -->
