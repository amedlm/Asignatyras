## Descripción

<!-- Describe brevemente qué hace este Pull Request -->

## Tipo de cambio

- [ ] feat: nueva práctica, diapositiva o ejemplo
- [ ] fix: corrección de error en material existente
- [ ] docs: cambio en documentación
- [ ] style: formato, sin cambio de contenido
- [ ] refactor: reorganización de carpetas
- [ ] test: nuevos tests de validación MARC 21 / Dublin Core

## Unidad/es afectada/s

<!-- ej. u3-indizacion -->

## Checklist de autoevaluación

- [ ] He leído el [CONTRIBUTING.md](CONTRIBUTING.md)
- [ ] He verificado que mi cambio no rompe materiales existentes
- [ ] He probado que el registro MARC 21 / Dublin Core valida
- [ ] He añadido o actualizado documentación si corresponde
- [ ] He citado fuentes externas utilizadas
- [ ] Mis commits siguen la convención Conventional Commits

## Capturas / evidencias (si aplica)

<!-- Pega aquí capturas o enlaces a evidencias -->

## Issues cerrados

<!-- Ej: Closes #23, Fixes #45 -->
Closes #
