# UCLV-CINFO — Departamento de Ciencias de la Información

![License](https://img.shields.io/badge/materials-CC%20BY--SA%204.0-blue)
![UCLV](https://img.shields.io/badge/UCLV-Santa%20Clara%2C%20Cuba-red)

Organización GitHub del **Departamento de Ciencias de la Información** de la
Universidad Central «Marta Abreu» de Las Villas (UCLV), Santa Clara, Cuba.

Aquí se alojan los **recursos educativos abiertos** de las asignaturas del
Departamento, publicados bajo licencia Creative Commons Atribución-CompartirIgual
4.0 (CC BY-SA 4.0) para favorecer su reutilización por la comunidad
iberoamericana de Ciencias de la Información.

---

## Repositorios

| Repositorio                          | Asignatura                | Desde  |
|--------------------------------------|---------------------------|--------|
| [`web-semantica`](./web-semantica)   | Web Semántica             | 2016   |
| [`analisis-documental`](./analisis-documental) | Análisis Documental I | 2012 |

## Líneas docentes e investigativas

- **Web Semántica y Datos Enlazados**: ontologías OWL, RDF, SPARQL, SKOS,
  aplicaciones en bibliotecas y sistemas de información científica.
- **Análisis documental**: catalogación MARC 21, Dublin Core, MODS,
  indización, resumen, control de autoridades.
- **Sistemas CRIS**: estándar CERIF, plataforma VIVO, interoperabilidad con
  OpenAIRE.
- **Innovación docente**: GitHub Classroom, aula invertida en STEM,
  rúbricas de evaluación formativa, H5P.

## Equipos y roles

| Equipo                       | Rol GitHub | Función                              |
|------------------------------|------------|--------------------------------------|
| Owners                       | Owner      | Administración de la organización    |
| Maintainers-WebSem           | Maintain   | Gestión del repo `web-semantica`     |
| Maintainers-AnalDoc          | Maintain   | Gestión del repo `analisis-documental` |
| Students-`<curso>`           | Read       | Matrícula oficial del curso          |
| Collaborators-Intl           | Read       | Profesores VLIR-UOS y aliados        |

## Cómo colaborar

1. Revisa los repositorios específicos para ver si tu contribución encaja.
2. Lee el `CONTRIBUTING.md` del repositorio correspondiente.
3. Abre un Issue para discutir tu propuesta antes de enviar un Pull Request
   externo.

## Contacto

- **Profesor responsable**: Amed Leiva-Mederos · Profesor Titular, UCLV
- **Correo**: amedcuba73@gmail.com
- **ORCID**: <https://orcid.org/0009-0001-5050-5563>

## Licencia

Salvo indicación contraria en un repositorio concreto, los materiales de esta
organización se distribuyen bajo licencia
[CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/).
